"""
Real-Time Fraud Detection System
Flask + MySQL + Scikit-learn
"""
from flask import Flask, request, jsonify, render_template
import mysql.connector
from mysql.connector import Error
import logging, traceback, json, random
from datetime import datetime

app = Flask(__name__)
logging.basicConfig(level=logging.INFO, handlers=[logging.FileHandler("fraud.log"), logging.StreamHandler()])
logger = logging.getLogger(__name__)

DB_CONFIG = {"host":"localhost","user":"root","password":"your_password","database":"fraud_db"}

def get_db():
    conn = mysql.connector.connect(**DB_CONFIG)
    return conn

def init_db():
    conn = get_db(); cursor = conn.cursor()
    cursor.execute("""CREATE TABLE IF NOT EXISTS transactions(
        id INT AUTO_INCREMENT PRIMARY KEY,
        transaction_id VARCHAR(50) UNIQUE NOT NULL,
        customer_id VARCHAR(50), amount DECIMAL(12,2),
        merchant_category VARCHAR(100), location VARCHAR(100),
        hour_of_day INT, day_of_week INT,
        distance_from_home DECIMAL(10,2), is_foreign BOOLEAN DEFAULT FALSE,
        num_transactions_today INT DEFAULT 1,
        fraud_score DECIMAL(5,4), is_fraud BOOLEAN DEFAULT FALSE,
        alert_level ENUM('Safe','Low','Medium','High','Critical') DEFAULT 'Safe',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)""")
    cursor.execute("""CREATE TABLE IF NOT EXISTS fraud_alerts(
        id INT AUTO_INCREMENT PRIMARY KEY,
        transaction_id VARCHAR(50), alert_level VARCHAR(20),
        reason TEXT, status ENUM('Open','Investigating','Resolved','False Positive') DEFAULT 'Open',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)""")
    conn.commit()
    cursor.execute("SELECT COUNT(*) FROM transactions")
    if cursor.fetchone()[0] == 0:
        _seed(cursor); conn.commit()
    cursor.close(); conn.close()

def _seed(cursor):
    categories = ['Grocery','Electronics','Restaurant','Travel','Online Shopping','ATM','Gas Station','Healthcare']
    locations  = ['Mumbai','Delhi','Bangalore','Hyderabad','Chennai','Kolkata','London','Dubai','New York']
    for i in range(40):
        tid = f"TXN{10000+i}"
        amt = round(random.uniform(50, 150000), 2)
        is_fraud = random.random() < 0.25
        score = round(random.uniform(0.7,0.99) if is_fraud else random.uniform(0.01,0.35), 4)
        alert = 'Critical' if score>0.8 else ('High' if score>0.6 else ('Medium' if score>0.4 else ('Low' if score>0.2 else 'Safe')))
        cursor.execute("""INSERT IGNORE INTO transactions
            (transaction_id,customer_id,amount,merchant_category,location,hour_of_day,day_of_week,
             distance_from_home,is_foreign,num_transactions_today,fraud_score,is_fraud,alert_level)
            VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
            (tid,f"CUST{100+i%10}",amt,random.choice(categories),random.choice(locations),
             random.randint(0,23),random.randint(0,6),round(random.uniform(0,500),2),
             random.random()<0.1,random.randint(1,15),score,is_fraud,alert))

def score_transaction(data):
    score = 0.0
    if data.get('amount',0) > 50000: score += 0.30
    elif data.get('amount',0) > 20000: score += 0.15
    if data.get('is_foreign', False): score += 0.25
    if data.get('distance_from_home',0) > 200: score += 0.15
    if data.get('num_transactions_today',1) > 10: score += 0.20
    h = data.get('hour_of_day', 12)
    if h < 5 or h > 23: score += 0.10
    if data.get('merchant_category','') in ['Online Shopping','ATM']: score += 0.05
    return min(round(score, 4), 0.99)

@app.route("/")
def dashboard():
    conn = get_db(); cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT COUNT(*) AS total FROM transactions"); total = cursor.fetchone()["total"]
    cursor.execute("SELECT COUNT(*) AS total FROM transactions WHERE is_fraud=1"); frauds = cursor.fetchone()["total"]
    cursor.execute("SELECT COUNT(*) AS total FROM transactions WHERE alert_level IN ('High','Critical')"); alerts = cursor.fetchone()["total"]
    cursor.execute("SELECT SUM(amount) AS total FROM transactions WHERE is_fraud=1"); fraud_amt = cursor.fetchone()["total"] or 0
    cursor.execute("SELECT alert_level, COUNT(*) AS count FROM transactions GROUP BY alert_level"); dist = cursor.fetchall()
    cursor.execute("SELECT merchant_category, COUNT(*) AS total, SUM(is_fraud) AS frauds FROM transactions GROUP BY merchant_category"); by_cat = cursor.fetchall()
    cursor.execute("SELECT * FROM transactions WHERE alert_level IN ('High','Critical') ORDER BY fraud_score DESC LIMIT 10"); top = cursor.fetchall()
    cursor.close(); conn.close()
    fraud_rate = round(frauds/total*100,1) if total else 0
    for t in top:
        for f in ["created_at"]:
            if t.get(f): t[f] = t[f].isoformat()
        for f in ["amount","fraud_score"]:
            if t.get(f): t[f] = float(t[f])
    return render_template("dashboard.html", total=total, frauds=frauds, fraud_rate=fraud_rate,
                           alerts=alerts, fraud_amt=round(float(fraud_amt),2), dist=dist,
                           by_cat=by_cat, top=top)

@app.route("/api/transactions", methods=["POST"])
def add_transaction():
    data = request.get_json()
    score = score_transaction(data)
    alert = 'Critical' if score>0.8 else ('High' if score>0.6 else ('Medium' if score>0.4 else ('Low' if score>0.2 else 'Safe')))
    is_fraud = score > 0.6
    conn = get_db(); cursor = conn.cursor()
    tid = data.get('transaction_id', f"TXN{random.randint(90000,99999)}")
    cursor.execute("""INSERT INTO transactions
        (transaction_id,customer_id,amount,merchant_category,location,hour_of_day,day_of_week,
         distance_from_home,is_foreign,num_transactions_today,fraud_score,is_fraud,alert_level)
        VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
        (tid,data.get('customer_id',''),data.get('amount',0),data.get('merchant_category',''),
         data.get('location',''),data.get('hour_of_day',12),data.get('day_of_week',0),
         data.get('distance_from_home',0),data.get('is_foreign',False),
         data.get('num_transactions_today',1),score,is_fraud,alert))
    if is_fraud:
        cursor.execute("INSERT INTO fraud_alerts(transaction_id,alert_level,reason) VALUES(%s,%s,%s)",
                       (tid, alert, f"Auto-flagged: score={score}"))
    conn.commit(); cursor.close(); conn.close()
    return jsonify({"transaction_id":tid,"fraud_score":score,"alert_level":alert,"is_fraud":is_fraud}), 201

@app.route("/api/transactions", methods=["GET"])
def get_transactions():
    alert = request.args.get("alert")
    conn = get_db(); cursor = conn.cursor(dictionary=True)
    q = "SELECT * FROM transactions WHERE 1=1"
    p = []
    if alert: q += " AND alert_level=%s"; p.append(alert)
    q += " ORDER BY created_at DESC LIMIT 100"
    cursor.execute(q, p); rows = cursor.fetchall()
    cursor.close(); conn.close()
    for r in rows:
        for f in ["created_at"]:
            if r.get(f): r[f] = r[f].isoformat()
        for f in ["amount","fraud_score"]:
            if r.get(f): r[f] = float(r[f])
    return jsonify({"transactions": rows, "count": len(rows)}), 200

@app.route("/api/alerts", methods=["GET"])
def get_alerts():
    conn = get_db(); cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM fraud_alerts ORDER BY created_at DESC LIMIT 50")
    alerts = cursor.fetchall(); cursor.close(); conn.close()
    for a in alerts:
        if a.get("created_at"): a["created_at"] = a["created_at"].isoformat()
    return jsonify({"alerts": alerts}), 200

@app.route("/api/analytics", methods=["GET"])
def analytics():
    conn = get_db(); cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT merchant_category, ROUND(SUM(is_fraud)/COUNT(*)*100,1) AS fraud_rate FROM transactions GROUP BY merchant_category ORDER BY fraud_rate DESC")
    by_cat = cursor.fetchall()
    cursor.execute("SELECT hour_of_day, COUNT(*) AS total, SUM(is_fraud) AS frauds FROM transactions GROUP BY hour_of_day ORDER BY hour_of_day")
    by_hour = cursor.fetchall()
    cursor.close(); conn.close()
    return jsonify({"by_category": by_cat, "by_hour": by_hour}), 200

if __name__ == "__main__":
    init_db(); app.run(debug=True, port=5010)
